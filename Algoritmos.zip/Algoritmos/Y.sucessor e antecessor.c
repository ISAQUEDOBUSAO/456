#include<stdio.h>
int main()
{
    int n, s, a;
    printf("escreva o numero desejado:");
    scanf("%i" , &n);
    a = n - 1;
    printf("antecessor:%i\n", a);
    s = n + 1;
    printf("sucessor: %i\n", s);
}
