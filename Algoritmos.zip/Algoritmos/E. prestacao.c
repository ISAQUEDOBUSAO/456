#include<stdio.h>
int main()
{
    float v, tp, t, p;
    printf("escreva o valor da prestacao:");
    scanf("%f", &v);
    printf("escreva a taxa percentual:");
    scanf("%f", &tp);
    printf("escreva o tempo da divida :");
    scanf("%f" ,&t);
    p = v +( v * ( tp / 100 ))*t;
    printf("prestacao: %.2f \n", p);
}
