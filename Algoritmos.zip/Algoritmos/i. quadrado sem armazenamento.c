#include<stdio.h>
#include<math.h>
int main()
{
    int m;
    printf("escreva um valor para m:");
    scanf("%f",&m);
    pow(m,2);
}
