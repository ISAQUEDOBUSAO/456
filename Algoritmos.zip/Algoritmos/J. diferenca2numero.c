#include<stdio.h>
float main()
{
    float A, B, C;
    printf("escreva o valor de A:");
    scanf("%f",&A);
    printf("escreva o valor de B:");
    scanf("%f",&B);
    C = A - B;
    printf("Diferenca de A e B: %.2f ", C); 
}