#include<stdio.h>
void main()
{
    int a, b, c;
    printf("escreva a:");
    scanf("%i" , &a);
    printf("escreva b:");
    scanf("%i", &b);
    c = a;
    a = b;
    b = c;
    printf("a: %i" ,a );
    printf( " b; %i",b );
}
